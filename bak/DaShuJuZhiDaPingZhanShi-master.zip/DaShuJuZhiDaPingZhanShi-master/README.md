# 大屏数据展示

#### 介绍
各类大屏展示模板持续更新中...

![智慧物流](https://images.gitee.com/uploads/images/2019/0614/130751_e439728b_2327318.png "智慧物流.png")
![舆情分析](https://images.gitee.com/uploads/images/2019/0614/130021_887dc34c_2327318.png "舆情分析.png")
![智慧社区](https://images.gitee.com/uploads/images/2019/0614/130053_5cfd9a55_2327318.png "智慧社区.png")
![智慧医疗](https://images.gitee.com/uploads/images/2019/0614/135158_55f95840_2327318.png "智慧医疗.png")
![车联网](https://images.gitee.com/uploads/images/2019/0614/130113_bb7810bd_2327318.png "车联网.png")
![环境监测](https://images.gitee.com/uploads/images/2019/0614/130316_9bfc9ac7_2327318.png "环境监测.png")
![电子商务](https://images.gitee.com/uploads/images/2019/0614/130335_a60a9904_2327318.png "电子商务.png")
![智慧交通](https://images.gitee.com/uploads/images/2019/1226/025508_8a651c15_2327318.png "智慧交通.png")


### 收集不易，劳烦各位star：）
